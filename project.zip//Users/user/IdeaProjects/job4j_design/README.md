# job4j_design
[![Build Status](https://travis-ci.com/rpegorov/job4j_design.svg?branch=master)](https://travis-ci.com/rpegorov/job4j_design)
[![codecov](https://codecov.io/gh/rpegorov/job4j_design/branch/master/graph/badge.svg)](https://codecov.io/gh/rpegorov/job4j_design)