import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class TriggerTest {

    @Test
    public void someLogic() {
        Assert.assertEquals(1, new Trigger().someLogic());
    }
}